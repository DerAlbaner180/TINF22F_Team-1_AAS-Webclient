# Project Documentation

## Responsibilities 
* BC: Dominik, Samara
* CRS: Rittmann, Martin
* MeetingMinutes: Engelmann, Tom
* PM: Dominik, Samara
* Presentations: Niedermeier, Anja; Dominik, Samara
* SAS: Hintze, Marcel
* SRS: Helms, Severin
* Usability Tests: Rittmann, Martin
* STP: Niedermeier, Anja
* STR: Engelmann, Tom
* User Manual: Engelmann, Tom
* Module Documentation: All

